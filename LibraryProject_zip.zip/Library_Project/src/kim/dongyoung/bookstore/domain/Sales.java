package kim.dongyoung.bookstore.domain;

import java.util.HashMap;
import java.util.Map;

public class Sales {//구매완료 목록
	
	public static Map<Integer,Book> sales = new HashMap<Integer,Book>();
	
	
	

}
