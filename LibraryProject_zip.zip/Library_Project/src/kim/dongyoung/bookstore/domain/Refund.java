package kim.dongyoung.bookstore.domain;

import java.util.HashMap;
import java.util.Map;

public class Refund {//환불목록
	
	public static Map<Integer,Book> refund= new HashMap<Integer,Book>();
	//"고객환불" 내용을 담아뒀음.

}
