package kim.dongyoung.bookstore.domain;

import java.util.HashMap;
import java.util.Map;

public class Cart {//장바구니
	
	public static Map<Integer,Book> cart= new HashMap<Integer,Book>();
	
}
