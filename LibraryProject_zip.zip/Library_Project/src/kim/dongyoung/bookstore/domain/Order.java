package kim.dongyoung.bookstore.domain;

import java.util.HashMap;
import java.util.Map;

public class Order {//주문목록
	
	public static Map<Integer,Book> order= new HashMap<Integer,Book>();

}
