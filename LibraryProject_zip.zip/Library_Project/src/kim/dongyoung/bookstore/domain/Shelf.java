package kim.dongyoung.bookstore.domain;

import java.util.HashMap;
import java.util.Map;

public class Shelf extends Book {//도서목록
	
	public static Map<Integer,Book> book = new HashMap<Integer,Book>();
   
	
	
}

