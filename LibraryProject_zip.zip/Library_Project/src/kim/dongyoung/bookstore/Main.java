
package kim.dongyoung.bookstore;

import kim.dongyoung.bookstore.service.Shop;

public class Main {
	public static void main(String[]args) {

		Shop shop = new Shop();
		
		shop.open(); //샵 문을 연다.
		
        
	}

	
}


