
package kim.dongyoung.bookstore.service;

import kim.dongyoung.bookstore.presentation.Console;

public class Shop {
	
	Console con = new Console();
	
	public void open() {
		con.Console(); //콘솔
	}
	}